﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportToken.Models
{
    public class ResultJson
    {
        public string EmbedToken { get; set; }
        public string EmbedUrl { get; set; }
        public string ReportId { get; set; }

    }
}
