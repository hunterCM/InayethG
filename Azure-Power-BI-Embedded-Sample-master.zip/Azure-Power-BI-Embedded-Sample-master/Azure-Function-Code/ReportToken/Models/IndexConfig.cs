﻿namespace ReportToken.Models
{
    public class IndexConfig
    {
        public string DotNETSDK { get; internal set; }
    }
}